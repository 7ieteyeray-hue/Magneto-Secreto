package com.yeray.magnetosecreto

import android.app.Activity
import android.content.Context
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.os.Build
import android.os.Bundle
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import android.graphics.Color
import android.graphics.Typeface
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.TextView
import java.util.Locale
import kotlin.math.sqrt

class MainActivity : Activity(), SensorEventListener {
    private lateinit var sensorManager: SensorManager
    private var magneticSensor: Sensor? = null
    private lateinit var statusText: TextView
    private lateinit var valueText: TextView
    private lateinit var thresholdText: TextView
    private lateinit var startButton: Button
    private lateinit var stopButton: Button
    private lateinit var thresholdBar: SeekBar

    private var detecting = false
    private var calibrating = false
    private var calibrationTotal = 0.0
    private var calibrationCount = 0
    private var baseline = 0.0
    private var hasBaseline = false
    private var alreadyBuzzed = false
    private var lastBuzzAt = 0L
    private var threshold = 10.0

    private val bg = Color.rgb(16, 17, 20)
    private val panel = Color.rgb(29, 30, 35)
    private val gold = Color.rgb(216, 182, 106)
    private val white = Color.WHITE
    private val muted = Color.rgb(174, 176, 184)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        sensorManager = getSystemService(Context.SENSOR_SERVICE) as SensorManager
        magneticSensor = sensorManager.getDefaultSensor(Sensor.TYPE_MAGNETIC_FIELD)
        buildUi()

        if (magneticSensor == null) {
            statusText.text = "Este móvil no ofrece un sensor magnético compatible."
            startButton.isEnabled = false
        } else {
            // Inicio automático: al abrir la app, empieza la calibración.
            startCalibration()
        }
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(dp(24), dp(26), dp(24), dp(22))
            setBackgroundColor(bg)
        }

        val title = TextView(this).apply {
            text = "MAGNETO SECRETO"
            textSize = 25f
            setTextColor(gold)
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
        }
        root.addView(title, matchWrap())

        val subtitle = TextView(this).apply {
            text = "Detector magnético para tu rutina"
            textSize = 14f
            setTextColor(muted)
            gravity = Gravity.CENTER
            setPadding(0, dp(8), 0, dp(24))
        }
        root.addView(subtitle, matchWrap())

        val panelLayout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(18), dp(18), dp(18))
            setBackgroundColor(panel)
        }

        statusText = TextView(this).apply {
            text = "Preparado"
            textSize = 20f
            setTextColor(white)
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
        }
        panelLayout.addView(statusText, matchWrap())

        valueText = TextView(this).apply {
            text = "Variación: -- µT"
            textSize = 16f
            setTextColor(gold)
            gravity = Gravity.CENTER
            setPadding(0, dp(16), 0, dp(4))
        }
        panelLayout.addView(valueText, matchWrap())

        val hint = TextView(this).apply {
            text = "Pulsa INICIAR y deja el móvil quieto durante la calibración."
            textSize = 13f
            setTextColor(muted)
            gravity = Gravity.CENTER
            setPadding(0, dp(8), 0, dp(12))
        }
        panelLayout.addView(hint, matchWrap())
        root.addView(panelLayout, LinearLayout.LayoutParams(-1, -2))

        thresholdText = TextView(this).apply {
            text = "Sensibilidad: 10 µT"
            textSize = 15f
            setTextColor(white)
            setPadding(0, dp(22), 0, dp(4))
        }
        root.addView(thresholdText, matchWrap())

        thresholdBar = SeekBar(this).apply {
            max = 95
            progress = 5 // 5 + 5 = 10 µT
            progressTintList = android.content.res.ColorStateList.valueOf(gold)
            thumbTintList = android.content.res.ColorStateList.valueOf(gold)
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                    threshold = (5 + progress).toDouble()
                    thresholdText.text = "Sensibilidad: ${threshold.toInt()} µT"
                }
                override fun onStartTrackingTouch(seekBar: SeekBar?) {}
                override fun onStopTrackingTouch(seekBar: SeekBar?) {}
            })
        }
        root.addView(thresholdBar, matchWrap())

        val buttons = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            setPadding(0, dp(18), 0, dp(12))
        }
        startButton = Button(this).apply {
            text = "INICIAR"
            setTextColor(Color.BLACK)
            setBackgroundColor(gold)
            setOnClickListener { startCalibration() }
        }
        stopButton = Button(this).apply {
            text = "PARAR"
            setOnClickListener { stopDetection() }
            isEnabled = false
        }
        buttons.addView(startButton, LinearLayout.LayoutParams(0, dp(52), 1f).apply {
            marginEnd = dp(8)
        })
        buttons.addView(stopButton, LinearLayout.LayoutParams(0, dp(52), 1f).apply {
            marginStart = dp(8)
        })
        root.addView(buttons, matchWrap())

        val foot = TextView(this).apply {
            text = "Consejo: prueba a varias distancias. El umbral depende del objeto y del entorno."
            textSize = 12f
            setTextColor(muted)
            gravity = Gravity.CENTER
            setPadding(0, dp(8), 0, 0)
        }
        root.addView(foot, matchWrap())
        setContentView(root)
    }

    private fun startCalibration() {
        val sensor = magneticSensor
        if (sensor == null) {
            statusText.text = "Sensor magnético no disponible"
            return
        }
        sensorManager.unregisterListener(this)
        detecting = true
        calibrating = true
        calibrationTotal = 0.0
        calibrationCount = 0
        baseline = 0.0
        hasBaseline = false
        alreadyBuzzed = false
        statusText.text = "Calibrando… deja el móvil quieto"
        valueText.text = "Variación: midiendo entorno"
        startButton.isEnabled = false
        stopButton.isEnabled = true
        sensorManager.registerListener(this, sensor, SensorManager.SENSOR_DELAY_GAME)
    }

    override fun onSensorChanged(event: SensorEvent) {
        if (!detecting || event.sensor.type != Sensor.TYPE_MAGNETIC_FIELD) return
        val x = event.values[0].toDouble()
        val y = event.values[1].toDouble()
        val z = event.values[2].toDouble()
        val magnitude = sqrt(x * x + y * y + z * z)

        if (calibrating) {
            calibrationTotal += magnitude
            calibrationCount++
            valueText.text = "Calibrando: $calibrationCount lecturas"
            if (calibrationCount >= 35) {
                baseline = calibrationTotal / calibrationCount
                hasBaseline = true
                calibrating = false
                statusText.text = "Detector activo"
                valueText.text = "Variación: 0,0 µT"
            }
            return
        }

        if (!hasBaseline) return
        val delta = kotlin.math.abs(magnitude - baseline)
        valueText.text = String.format(Locale.getDefault(), "Variación: %.1f µT", delta)

        if (delta >= threshold && !alreadyBuzzed) {
            alreadyBuzzed = true
            statusText.text = "¡IMÁN DETECTADO!"
            val now = android.os.SystemClock.elapsedRealtime()
            if (now - lastBuzzAt >= 700L) {
                vibrate()
                lastBuzzAt = now
            }
        } else if (delta < threshold * 0.65) {
            alreadyBuzzed = false
            statusText.text = "Detector activo"
        }
    }

    private fun vibrate() {
        val vibrator: Vibrator = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            val manager = getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as VibratorManager
            manager.defaultVibrator
        } else {
            @Suppress("DEPRECATION")
            getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
        }
        if (!vibrator.hasVibrator()) return
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            vibrator.vibrate(VibrationEffect.createOneShot(180, VibrationEffect.DEFAULT_AMPLITUDE))
        } else {
            @Suppress("DEPRECATION")
            vibrator.vibrate(180)
        }
    }

    private fun stopDetection() {
        detecting = false
        calibrating = false
        hasBaseline = false
        sensorManager.unregisterListener(this)
        statusText.text = "Detector detenido"
        valueText.text = "Variación: -- µT"
        startButton.isEnabled = true
        stopButton.isEnabled = false
    }

    override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {}

    override fun onPause() {
        if (::sensorManager.isInitialized && detecting) {
            stopDetection()
        } else if (::sensorManager.isInitialized) {
            sensorManager.unregisterListener(this)
        }
        super.onPause()
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()

    private fun matchWrap() = LinearLayout.LayoutParams(
        LinearLayout.LayoutParams.MATCH_PARENT,
        LinearLayout.LayoutParams.WRAP_CONTENT
    )
}
