MAGNETO SECRETO — prototipo Android
==================================

Comportamiento
--------------
Al abrir la app, inicia automáticamente una calibración breve del campo
magnético ambiental. Después, vibra al detectar una variación superior al
umbral ajustable (10 µT por defecto). La pantalla muestra la variación y
permite ajustar la sensibilidad. Si se cierra la app o se sale de ella,
el detector se detiene; vuelve a abrirla para activarlo.

IMPORTANTE
----------
- El sensor detecta campos magnéticos, no cualquier metal.
- Un anillo normal de oro o plata puede no producir una señal detectable.
- El sensor no identifica por sí mismo qué mano contiene el objeto.
- La sensibilidad y el alcance dependen del imán, la orientación y el entorno.
- No se ha compilado ni probado físicamente en un Galaxy A56; es código fuente
  preparado para compilar en Android Studio.

Cómo generar un APK
-------------------
1. Instala Android Studio en un ordenador.
2. Descomprime el ZIP y abre la carpeta MagnetoSecreto.
3. Espera a que termine la sincronización de Gradle.
4. Selecciona Build > Build APK(s).
5. Android Studio indicará dónde guardó el APK.
