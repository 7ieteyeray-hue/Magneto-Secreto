MAGNETO SECRETO — prototipo Android
==================================

Comportamiento
--------------
Al abrir la app, inicia automáticamente una calibración breve del campo
magnético ambiental. Después, vibra al detectar una variación superior al
umbral ajustable (10 µT por defecto). La pantalla muestra la variación y
permite ajustar la sensibilidad. Si se cierra la app o se sale de ella,
el detector se detiene; vuelve a abrirla para activarlo.

IMPORTANTE
----------
- El sensor detecta campos magnéticos, no cualquier metal.
- Un anillo normal de oro o plata puede no producir una señal detectable.
- El sensor no identifica por sí mismo qué mano contiene el objeto.
- La sensibilidad y el alcance dependen del imán, la orientación y el entorno.
- Este código no se ha compilado ni probado físicamente en un Galaxy A56.

Cómo conseguir el APK mediante compilación en la nube
----------------------------------------------------
Se incluye .github/workflows/build-apk.yml para que GitHub Actions compile
el APK automáticamente.

1. En un ordenador, crea un repositorio nuevo en GitHub.
2. Sube todos los archivos de esta carpeta al repositorio (incluido .github).
3. Abre la pestaña Actions del repositorio y selecciona "Build Magneto Secreto APK".
4. Pulsa "Run workflow" si no se ha iniciado automáticamente.
5. Cuando termine correctamente, entra en la ejecución y descarga el artefacto
   "Magneto-Secreto-APK". Dentro estará app-debug.apk.
6. Pasa el APK al móvil y ábrelo para instalarlo. Android puede pedir permiso
   para instalar aplicaciones de esa fuente; hazlo solo si confías en el origen.

La compilación en GitHub requiere que el usuario tenga una cuenta y suba el
proyecto. No se ha generado un APK desde esta sesión.
